<?php
$server = 'localhost';
$username = 'root';
$password = '';
$db = 'students';

$connection = mysqli_connect($server, $username, $password, $db);

?>







