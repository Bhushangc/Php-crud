<?php require("connection.php");
//isset
if (isset($_GET["id"])){
    $id = $_GET["id"];
    $query = "SELECT * FROM student_info WHERE id='$id'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_array($result);
}
?>
<form action="update.php" method="post">
    <input type="text" name="id" value = "<?php echo $id;?>" hidden> <?php // this makes sure once you post id will also go once you submit ?>
    name: <input type="text"  name="name"> <br>
    phone: <input type="text" name="phone"> <br>
    address: <input type="text" name="address"> <br>
    <input type="submit">
</form>
<?php
if (isset($_POST["name"]) && isset($_POST["phone"]) && isset($_POST["address"]) && isset($_POST["id"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];

    $query = "UPDATE student_info SET phone ='$phone' , address = '$address' , name = '$name' WHERE id ='$id';";
    
    if ($connection->query($query) == TRUE) {
        header('Location: fetch.php');
    } else {
        echo $connection->error;
    }
}
?>