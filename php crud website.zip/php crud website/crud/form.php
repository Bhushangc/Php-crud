<?php require('connection.php')?>
<form action = "form.php" method= "post">
        name <input type = "text" name = "name"> <br>
        phone <input type = "text" name = "phone"> <br>
        address <input type = "text" name = "address"> <br>
        <input type = "submit">
</form>
<br> <br>
    <?php
    if (isset($_POST["name"]) &&  isset($_POST["phone"]) &&  (isset($_POST["address"]))){
        $name = $_POST["name"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $id = rand(1,100);
        
        // $query = "INSERT INTO 'Student_info' VALUES ('$name', '$phone', '$address';)";

        $query = "Insert into `student_info` values('$name', '$phone', '$address','$id');";
        
        if ($connection->query($query) ==TRUE) {
            header ('Location:fetch.php');
            
        }
        else
        {
            echo $connection->error;
        }
    
}
?>
